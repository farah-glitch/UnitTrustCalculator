package com.example.unittrustcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText inputAmount, inputRate, inputMonths;
    Button btnCalculate;
    TextView outputResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputAmount = findViewById(R.id.inputAmount);
        inputRate = findViewById(R.id.inputRate);
        inputMonths = findViewById(R.id.inputMonths);
        btnCalculate = findViewById(R.id.btnCalculate);
        outputResult = findViewById(R.id.outputResult);

        btnCalculate.setOnClickListener(v -> calculateDividend());
    }

    private void calculateDividend() {
        if (inputAmount.getText().toString().isEmpty() ||
                inputRate.getText().toString().isEmpty() ||
                inputMonths.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please fill in all inputs!", Toast.LENGTH_SHORT).show();
            return;
        }

        double invested = Double.parseDouble(inputAmount.getText().toString());
        double rate = Double.parseDouble(inputRate.getText().toString()) / 100;
        int months = Integer.parseInt(inputMonths.getText().toString());

        if (months > 12) {
            Toast.makeText(this, "Months cannot exceed 12!", Toast.LENGTH_SHORT).show();
            return;
        }

        double monthlyDividend = (rate / 12) * invested;
        double totalDividend = monthlyDividend * months;

        outputResult.setText(
                "Monthly Dividend: RM " + String.format("%.2f", monthlyDividend) +
                        "\nTotal Dividend: RM " + String.format("%.2f", totalDividend)
        );
    }

    // ---- Menu Code ----
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_about) {
            startActivity(new Intent(MainActivity.this, AboutActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
